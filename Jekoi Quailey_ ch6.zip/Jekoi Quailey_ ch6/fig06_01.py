#jekoi Quailey # fig06_01.py
"""Using a dictionary to represent an instructor's grade book."""
grade_book = {            
    'Susan': [88, 90, 100], 
    'Eduardo': [33, 45, 98],
    'Azizi': [77, 68, 55],  
    'Pantipa': [86, 20, 99] 
}

all_grades_total = 0
all_grades_count = 0

for name, grades in grade_book.items():
    total = sum(grades)
    print(f'Average for {name} is {total/len(grades):.2f}')
    all_grades_total += total
    all_grades_count += len(grades)
    
print(f"Class's average is: {all_grades_total / all_grades_count:.2f}")

OUTPUT
Average for Susan is 92.67
Average for Eduardo is 58.67
Average for Azizi is 66.67
Average for Pantipa is 68.33
Class's average is: 71.58