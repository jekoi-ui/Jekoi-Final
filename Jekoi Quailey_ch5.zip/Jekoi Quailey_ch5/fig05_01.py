#Jekoi Quailey # fig05_01.py
"""Displaying a bar chart"""
numbers = [97, 64, 30, 48, 19]

print('\nCreating a bar chart from numbers:')
print(f'Index{"Value":>6}   Bar')

for index, value in enumerate(numbers):
    print(f'{index:>5}{value:>6}   {"*" * value}')

OUTPUT

    0    97   *************************************************************************************************
    1    64   ****************************************************************
    2    30   ******************************
    3    48   ************************************************
    4    19   *******************