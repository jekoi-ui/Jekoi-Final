# fig04_03.py
"""Function-call stack demonstration script."""

def main():
    result = square(9)  # square's stack frame pushed onto stack here
    print('square(9):', result)  
    # main's stack frame is popped here

def square(number):
    return number ** 3  # square's stack frame is popped here

main()  # execution begins here
# when main returns, the script terminates here
 

OUTPUT
square(9): 729